import { useEffect, useState } from "react";
import api from "../../services/api";

export default function AffiliateClicks() {
  const [clicks, setClicks] = useState([]);

  useEffect(() => {
    api.get("/affiliate/clicks").then((res) => setClicks(res.data));
  }, []);

  return (
    <div>
      <h1 className="page-title">Clicks</h1>

      <table className="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>IP Address</th>
            <th>User Agent</th>
          </tr>
        </thead>

        <tbody>
          {clicks.map((c) => (
            <tr key={c.id}>
              <td>{new Date(c.createdAt).toLocaleString()}</td>
              <td>{c.ip}</td>
              <td>{c.userAgent}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
