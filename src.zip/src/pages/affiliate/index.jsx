import { useEffect, useState } from "react";
import axios from "../../utils/axios";

export default function AffiliateDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    axios.get("/affiliate/me").then(res => setData(res.data));
  }, []);

  if (!data) return <div className="p-10">Chargement…</div>;

  return (
    <div className="p-8 space-y-10">
      <h1 className="text-3xl font-bold">Tableau de bord affilié</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Stat title="Clics" value={data.clicks} />
        <Stat title="Conversions" value={data.conversions} />
        <Stat title="Revenus" value={(data.revenue / 100).toFixed(2) + " €"} />
      </div>

      <LinkGenerator code={data.code} />
      <ClicksTable clicks={data.lastClicks} />
      <ConversionsTable conv={data.lastConversions} />
    </div>
  );
}

function Stat({ title, value }) {
  return (
    <div className="p-6 bg-white shadow rounded-xl text-center">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-2xl font-bold mt-2">{value}</div>
    </div>
  );
}

function LinkGenerator({ code }) {
  const base = window.location.origin;
  const link = `${base}/?ref=${code}`;

  return (
    <div className="p-6 bg-white shadow rounded-xl space-y-4">
      <h2 className="font-semibold text-lg">Lien d’affiliation</h2>
      <input className="w-full border rounded p-2" value={link} readOnly />
      <button
        onClick={() => navigator.clipboard.writeText(link)}
        className="px-4 py-2 bg-blue-600 text-white rounded"
      >
        Copier
      </button>
    </div>
  );
}

function ClicksTable({ clicks }) {
  return (
    <div className="bg-white p-6 shadow rounded-xl">
      <h2 className="font-semibold mb-4">Derniers clics</h2>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="p-2">IP</th>
            <th className="p-2">Référent</th>
            <th className="p-2">Date</th>
          </tr>
        </thead>
        <tbody>
          {clicks.map(c => (
            <tr key={c.id} className="border-b">
              <td className="p-2">{c.ip}</td>
              <td className="p-2">{c.referer || "-"}</td>
              <td className="p-2">{new Date(c.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ConversionsTable({ conv }) {
  return (
    <div className="bg-white p-6 shadow rounded-xl">
      <h2 className="font-semibold mb-4">Dernières conversions</h2>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="p-2">Commande</th>
            <th className="p-2">Montant</th>
            <th className="p-2">Date</th>
          </tr>
        </thead>
        <tbody>
          {conv.map(c => (
            <tr key={c.id} className="border-b">
              <td className="p-2">{c.orderId}</td>
              <td className="p-2">{(c.amountCents / 100).toFixed(2)} €</td>
              <td className="p-2">{new Date(c.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
