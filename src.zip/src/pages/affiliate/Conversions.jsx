import { useEffect, useState } from "react";
import api from "../../services/api";

export default function AffiliateConversions() {
  const [conversions, setConversions] = useState([]);

  useEffect(() => {
    api.get("/affiliate/conversions").then((res) => setConversions(res.data));
  }, []);

  return (
    <div>
      <h1 className="page-title">Conversions</h1>

      <table className="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Order ID</th>
            <th>Amount</th>
            <th>Commission</th>
          </tr>
        </thead>

        <tbody>
          {conversions.map((c) => (
            <tr key={c.id}>
              <td>{new Date(c.createdAt).toLocaleString()}</td>
              <td>{c.orderId}</td>
              <td>{c.orderAmount} €</td>
              <td>{c.commission.toFixed(2)} €</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
