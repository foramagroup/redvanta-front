import api from "./api";
export const customizationService = {
  get: (orderId) => api.get(`/customization/${orderId}`).then(r => r.data),
  upsert: (orderId, payload) => api.post(`/customization/${orderId}`, payload).then(r => r.data)
};
