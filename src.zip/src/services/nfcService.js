import api from "./api";
export const nfcService = {
  fetchTag: (uid) => api.get(`/nfc/${uid}`).then(r => r.data)
};
