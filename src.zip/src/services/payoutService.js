import adminApi from "./adminApi";

export const payoutService = {
  list: () => adminApi.get("/payouts").then(r => r.data),
  create: (payload) => adminApi.post("/payouts/request", payload).then(r => r.data),
  approve: (id) => adminApi.post(`/payouts/${id}/approve`).then(r => r.data),
  decline: (id, reason) => adminApi.post(`/payouts/${id}/decline`, { reason }).then(r => r.data)
};
