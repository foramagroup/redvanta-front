import api from "./api";
export const productService = {
  list: () => api.get("/products").then(r => r.data),
  getBySlug: (slug) => api.get(`/products/${slug}`).then(r => r.data)
};
