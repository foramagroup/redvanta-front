import api from "./api";

export async function login(email, password) {
  const res = await api.post("/auth/login", { email, password });
  if (res.data?.token) localStorage.setItem("krootal_token", res.data.token);
  return res.data;
}

export function logout() {
  localStorage.removeItem("krootal_token");
}
