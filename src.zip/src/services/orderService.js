import api from "./api";
export const orderService = {
  createCheckoutSession: (items, email, affiliateCode) => api.post("/orders/create-checkout-session", { items, email, affiliateCode }).then(r => r.data)
};
