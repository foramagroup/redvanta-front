import api from "./api";
export const reviewService = {
  post: (payload) => api.post("/reviews", payload).then(r => r.data),
  list: () => api.get("/reviews").then(r => r.data)
};
